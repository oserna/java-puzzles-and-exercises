package le.flatten;

public interface Function<P, R> {

    R apply(P p);
}
